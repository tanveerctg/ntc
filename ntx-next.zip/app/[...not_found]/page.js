import React from "react";

const page = () => {
  return (
    <div
      style={{
        display: "flex",
        minHeight: "50vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      Not Found
    </div>
  );
};

export default page;
