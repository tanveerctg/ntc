const teamdata =
  [
    // {
    //   'id': 1,
    //   'name': "Nicci Topping",
    //   'role': "CEO",
    //   'description': (
    //     <>
    //       The big cheese, the<span style={{ fontStyle: 'italic' }}> Grande Fromage</span > of Nicci Topping Casting.
    //       <br />
    //       Etiam iaculis urna ipsum, ut luctus velit luctus vel.Fusce sem erat, congue ut sollicitudin eget, elementum et magna.
    //     </>)
    // },
    {
      'id': 2,
      'name': "Tony Dixon",
      'role': "Business Development Manager",
      'image': '/images/tony-dixon.jpg',
      'pronoun': " He / Him",
      'description': `Ut vulputate mauris id felis dapibus, sed lobortis neque dignissim.

        Etiam iaculis urna ipsum, ut luctus velit luctus vel.Fusce sem erat, congue ut sollicitudin eget, elementum et magna. `
    },
    {
      'id': 3,
      'name': "Sherelle Armstrong",
      'role': "Casting Assistant",
      'image': '/images/female-avatar.svg',
      'pronoun': " She / Her",
      'description': `Ut vulputate mauris id felis dapibus, sed lobortis neque dignissim.

        Etiam iaculis urna ipsum, ut luctus velit luctus vel.Fusce sem erat, congue ut sollicitudin eget, elementum et magna. `
    },
    {
      'id': 4,
      'name': "Annalise Bradshaw",
      'role': "Junior Casting Assistant",
      'image': '/images/annalise-bradshaw.jpg',
      'pronoun': " She / Her",
      'description': `Ut vulputate mauris id felis dapibus, sed lobortis neque dignissim.

        Etiam iaculis urna ipsum, ut luctus velit luctus vel.Fusce sem erat, congue ut sollicitudin eget, elementum et magna. `
    },
    {
      'id': 5,
      'name': "Che Rucker",
      'role': "Junior Casting Assistant",
      'image': '/images/che-rucker.jpg',
      'pronoun': " He / Him",
      'description': `Ut vulputate mauris id felis dapibus, sed lobortis neque dignissim.

        Etiam iaculis urna ipsum, ut luctus velit luctus vel.Fusce sem erat, congue ut sollicitudin eget, elementum et magna. `
    },
    {
      'id': 6,
      'name': "Natty Dimond-Lyons",
      'role': "Personal Assistant",
      'image': '/images/female-avatar.svg',
      'pronoun': " They / Them",
      'description': `Ut vulputate mauris id felis dapibus, sed lobortis neque dignissim.

        Etiam iaculis urna ipsum, ut luctus velit luctus vel.Fusce sem erat, congue ut sollicitudin eget, elementum et magna. `
    },
  ]


export { teamdata }

