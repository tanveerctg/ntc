const config = {
    projectId: 'y9e6hyu0',
    dataset: 'production',
    apiVersion: "2023-04-25",
    useCdn: true
}

export default config