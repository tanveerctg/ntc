import youtubeVideos from './youtube-schema'
import webPages from './webpage-schema'


export const schemaTypes = [
    youtubeVideos,
    webPages
]
